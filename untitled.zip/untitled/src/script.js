function rickRoll() {
  window.location.href = "https://www.youtube.com/watch?v=dQw4w9WgXcQ";
}
